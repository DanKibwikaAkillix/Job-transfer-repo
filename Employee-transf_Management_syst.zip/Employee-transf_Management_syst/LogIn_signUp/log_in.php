<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In</title>

<?php
// Include database connection
include 'DbConnection.php';

// Initialize session


// Define variables and initialize with empty values
$email = $password = "";
$email_err = $password_err = "";
$attempt_limit = 5;
$timeout_duration = 30; // in seconds

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Check if there are no input errors
    if (empty($email_err) && empty($password_err)) {
        // Prepare a SELECT statement
        $sql = "SELECT email, password, status FROM user_jobs_ystem WHERE email = ?";

        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("s", $param_email);

            // Set parameters
            $param_email = $email;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Store result
                $stmt->store_result();

                // Check if email exists, then verify password
                if ($stmt->num_rows == 1) {
                    // Bind result variables
                    $stmt->bind_result($email, $hashed_password, $status);
                    if ($stmt->fetch()) {
                        if (password_verify($password, $hashed_password)) {
                            // Password is correct, start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["email"] = $email;
                            include 'sendOTP.php';

                            // Redirect user based on status
                            if ($status == "Admin") {
                                header("Location: Admin/OTP.php?email=".$email);
                            } elseif ($status == "Employee") {
                                header("Location: Employee/OTP.php?email=".$email."");
                            } else {
                                // Reload the page
                                echo "<meta http-equiv='refresh' content='0'>";
                            }
                        } else {
                            // Display error message if password is not valid
                            $password_err = "Hmm... Something is missing.";
                        }
                    }
                } else {
                    // Display error message if email doesn't exist
                    $email_err = "User doesn't exist.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }

    // Close connection
    $conn->close();
}
?>

<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('https://assets3.thrillist.com/v1/image/2831917/1584x1056/crop;webp=auto;jpeg_quality=60;progressive.jpg');
    background-size: cover;
    background-position: center;
    height: 100vh;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .container {
    background-color: rgba(255, 255, 255, 0.8); /* Transparent white background */
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    max-width: 500px; /* Increased max-width */
    text-align: center;
    animation: fadeIn 1s ease; /* Fading animation */
  }
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  h1 {
    color: #333;
    margin-bottom: 20px;
  }
  input {
    padding: 15px; /* Increased padding */
    margin: 15px 0; /* Increased margin */
    width: calc(100% - 30px); /* Adjusted width for responsiveness */
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 6px; /* Slightly increased border-radius */
    font-size: 18px; /* Increased font size */
    transition: all 0.3s; /* Smooth transition */
  }
  input:focus {
    border-color: #007bff; /* Highlight on focus */
    outline: none; /* Remove default focus outline */
  }
  button {
    padding: 15px 30px; /* Increased padding */
    font-size: 18px; /* Increased font size */
    border: none;
    border-radius: 6px;
    background-color: #007bff;
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s;
    width: 100%;
    text-decoration: none;
    display: inline-block;
  }
  button:hover {
    background-color: #0056b3;
  }
  .form-link {
    display: inline-block;
    margin-top: 20px;
    font-size: 16px; /* Adjusted font size */
    color: #007bff;
    text-decoration: none;
    transition: color 0.3s;
  }
  .form-link:hover {
    color: #0056b3;
  }
</style>



</head>
<body>
<div class="container">
  <h1>Sign In</h1>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <input type="email" name="email" placeholder="Email" required value="<?php echo $email; ?>">
    <span style="color: red;"><?php echo $email_err; ?></span><br>
    <input type="password" name="password" placeholder="Password" required>
    <span style="color: red;"><?php echo $password_err; ?></span><br>
    <button type="submit">Sign In</button>
  </form>
  <a href="log_up.php" class="form-link">Don't have an account? Sign Up</a>
</div>
</body>
</html>
