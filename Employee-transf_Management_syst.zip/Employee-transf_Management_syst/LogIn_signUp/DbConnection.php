<?php
// Database credentials
$servername = "localhost"; // Replace with your MySQL server name
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "employee_management_system"; // Replace with your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Customized error message based on MySQL error code
    $error_message = "";
    switch ($conn->connect_errno) {
        case 1045:
            $error_message = "Access denied. Please check your username and password.";
            break;
        default:
            $error_message = "Sorry, there was an error connecting to the database.";
            break;
    }
    
    // Display error message with image
    echo "<div style='text-align: center;'>";
    echo "<img src='https://i.pinimg.com/564x/b0/de/75/b0de755d2943b5f201c3702fd59f20f8.jpg' alt='Error image' style='max-width: 100%;'>";
    echo "<h2>$error_message</h2>";
    echo "<p>Please try again later or contact the administrator for assistance.</p>";
    echo "</div>";
    die();
} else {
    // If connection is successful, display success message
    echo '';
}
?>
