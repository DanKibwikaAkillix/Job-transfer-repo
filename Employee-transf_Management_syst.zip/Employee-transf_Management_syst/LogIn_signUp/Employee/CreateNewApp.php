<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Transfer Portal Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        .dashboard2 {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .sidebar2 {
            background-color: #44576D;
            color: #fff;
            width: 290px; /* Adjusted width */
            flex-shrink: 0;
            padding: 20px;
            transition: transform 0.3s ease-in-out;
            position: fixed;
            top: 0;
            bottom: 0;
            overflow-y: auto;
            border-radius: 0px 10px 10px 0px;
            z-index: 1000;
        }
        .sidebar2 ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar2 li {
            margin-bottom: 15px;
        }
        .sidebar2 a {
            text-decoration: none;
            color: #fff;
            font-size: 17.5px;
            transition: background-color 0.3s, color 0.3s;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 5px ;
        }
        .sidebar2 a:hover {
            background-color: #5e738c;
            color: #fff;
        }
        .sidebar2 a i {
            margin-right: 10px;
        }
        .main-content2 {
            flex-grow: 1;
            padding: 20px;
            margin-left: 250px;
        }
        .menu-icon2 {
            display: none;
            font-size: 24px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .menu-icon2.active {
            transform: rotate(90deg);
        }
        @media (max-width: 768px) {
            .dashboard2 {
                overflow-x: hidden;
            }
            .sidebar2 {
                left: -250px;
            }
            .sidebar2.active {
                left: 0;
            }
            .main-content2 {
                margin-left: 0;
                padding-top: 80px;
            }
            .menu-icon2 {
                display: block;
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 1100;
            }
        }
        .profile2 {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }
        .profile2 img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .username2 {
            font-size: 16px;
        }

        .mainLi2 {
            background:#5e738c;
        }
    </style>
</head>
<body>
   
    <div class="dashboard2">
        <div class="sidebar2" id="sidebar2">
            <div class="profile2">
                <img src="https://i.pinimg.com/564x/7f/c4/c6/7fc4c6ecc7738247aac61a60958429d4.jpg" alt="Profile Picture">
                <div class="username2">John Doe</div>
            </div>
            <ul>
                <li class="mainLi2"><a href="myportal.php"><i class="fas fa-tasks"></i> View Applications</a></li>
                <li><a href="ProfileMy.php"><i class="fas fa-user"></i> View Profile</a></li>
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
            </ul>
        </div>
        <div class="main-content2">
            <div class="menu-icon2" onclick="toggleSidebar2()"><i class="fas fa-bars"></i></div>
            <!-- Your main content goes here -->
            <?php
            include ('CreateapplicationForm.php');
            ?>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <script>
    function toggleSidebar2() {
        var sidebar2 = document.getElementById('sidebar2');
        var menuIcon2 = document.querySelector('.menu-icon2');
        sidebar2.classList.toggle('active');
        menuIcon2.classList.toggle('active');
    }

    // Close sidebar when clicking outside of it
    window.onclick = function(event) {
        var sidebar2 = document.getElementById('sidebar2');
        var menuIcon2 = document.querySelector('.menu-icon2');
        if (!event.target.closest('.sidebar2') && !event.target.closest('.menu-icon2')) {
            sidebar2.classList.remove('active');
            menuIcon2.classList.remove('active');
        }
    };
</script>
</body>
</html>
