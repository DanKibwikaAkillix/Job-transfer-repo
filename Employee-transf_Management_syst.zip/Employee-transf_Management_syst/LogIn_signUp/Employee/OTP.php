<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>OTP Verification</title>

<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('https://assets3.thrillist.com/v1/image/2831917/1584x1056/crop;webp=auto;jpeg_quality=60;progressive.jpg');
    background-size: cover;
    background-position: center;
    height: 100vh;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .container {
    background-color: rgba(255, 255, 255, 0.9);
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    max-width: 600px;
    text-align: center;
    animation: slide-in 1s ease-out;
  }
  @keyframes slide-in {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }
  h1 {
    color: #333;
    margin-bottom: 20px;
  }
  p {
    color: #555;
    margin-bottom: 20px;
  }
  input {
    padding: 15px;
    margin: 15px 0;
    width: calc(100% - 30px);
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 18px;
    transition: all 0.3s;
  }
  input:focus {
    border-color: #007bff;
    outline: none;
  }
  a {
    text-decoration: none;
    padding: 15px 30px;
    font-size: 18px;
    border: none;
    border-radius: 6px;
    background-color: #007bff;
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s;
    width: 100%;
    display: inline-block;
  }
  a:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>

<?php
// Database connection
include '../DbConnection.php';

// Define variables and initialize with empty values
$otp = "";
$otp_err = "";
$email = $_GET["email"] ?? "";

// Check if email is provided in the URL
if (isset($_GET["email"])) {
    // Prepare a SELECT statement to retrieve OTP using email
    $sql = "SELECT otp FROM user_jobs_ystem WHERE email = '" . $email . "'";

    // Execute the statement
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Fetch the OTP from the database
        $row = $result->fetch_assoc();
        $db_otp = $row["otp"];

        // Check if form is submitted using the verify button
        if (isset($_POST["verify_button"])) {
            // Validate OTP
            if (empty(trim($_POST["otp"]))) {
                $otp_err = "Please enter the OTP.";
            } else {
                $otp = trim($_POST["otp"]);
            }

            // Check if OTP matches
            if ($otp === $db_otp) {
                // Redirect to myPortal.php with email in URL
                echo '<script>window.location.href = "myPortal.php?email=' . $email . '";</script>';
                exit();
            } else {
                // Show error message for 5 seconds using JavaScript
                echo '<script>setTimeout(function(){ document.getElementById("otp-error").style.display = "none"; }, 5000);</script>';
                $otp_err = "Incorrect OTP. Please try again.";
            }
        }
    } else {
        $otp_err = "User not found.";
    }
} else {
    $otp_err = "Invalid email provided.";
}
?>

<div class="container">
  <h1>OTP Verification</h1>
  <p>An OTP has been sent to your registered email. Please enter the OTP below:</p>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <input type="text" name="otp" placeholder="Enter OTP" required><br>
    <span style="color: red;" id="otp-error"><?php echo $otp_err; ?></span><br>
    <button type="submit" name="verify_button">Verify OTP</button>
  </form>
</div>

<script>
  // Show error message for 5 seconds using JavaScript
  setTimeout(function(){ document.getElementById("otp-error").style.display = "none"; }, 5000);
</script>

</body>
</html>
