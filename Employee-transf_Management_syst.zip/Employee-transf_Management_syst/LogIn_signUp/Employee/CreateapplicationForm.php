<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Profile Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url("https://img.freepik.com/premium-vector/abstract-white-shapes-background_79603-1360.jpg?w=826");
            background-size: cover;
            background-attachment: fixed;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        label {
            font-weight: 500;
        }

        .form-group {
            margin-bottom: 30px;
        }

        input[type="text"],
        input[type="password"],
        input[type="tel"],
        input[type="email"],
        select {
            width: 100%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="file"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Professional Profile Form</h1>
    <form id="profileForm">
        <!-- Section 1 -->
        <div id="section1">
            <div class="form-group">
                <label for="username">Enter Username</label>
                <input type="text" id="username" required>
            </div>
            <div class="form-group">
                <label for="password">Enter Password</label>
                <input type="password" id="password" required>
            </div>
            <div class="form-group">
                <label for="probation">Confirm Probation Status:</label><br>
                <input type="radio" id="probation_yes" name="probation" value="Yes">
                <label for="probation_yes">Yes</label>
                <input type="radio" id="probation_no" name="probation" value="No">
                <label for="probation_no">No</label>
            </div>
            <div class="form-group">
                <label for="other_specify">Specify Other (sick leave, rehabilitation, etc.)</label>
                <input type="text" id="other_specify">
            </div>
            <div class="btn-container">
                <button type="button" id="nextBtn1" class="btn btn-primary">Next</button>
            </div>
        </div>
        <!-- Section 2 -->
        <div id="section2" style="display: none;">
            <div class="form-group">
                <label for="preferred_region">Select Preferred Region</label>
                <select id="preferred_region">
                    <option value="Option 1">Option 1</option>
                    <option value="Option 2">Option 2</option>
                    <option value="Option 3">Option 3</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label for="preferred_town">Select Preferred Town</label>
                <select id="preferred_town">
                    <option value="Option 1">Option 1</option>
                    <option value="Option 2">Option 2</option>
                    <option value="Option 3">Option 3</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label for="first_name">Enter First Name</label>
                <input type="text" id="first_name">
            </div>
            <div class="form-group">
                <label for="last_name">Enter Last Name</label>
                <input type="text" id="last_name">
            </div>
            <div class="btn-container">
                <button type="button" id="prevBtn1" class="btn btn-secondary">Previous</button>
                <button type="button" id="nextBtn2" class="btn btn-primary">Next</button>
            </div>
        </div>
        <!-- Section 3 -->
        <div id="section3" style="display: none;">
            <div class="form-group">
                <label for="job_grade">Select Job Grade</label>
                <input type="text" id="job_grade">
            </div>
            <div class="form-group">
                <label for="current_employer">Enter Current Employer</label>
                <input type="text" id="current_employer">
            </div>
            <div class="form-group">
                <label for="town_of_current_employer">Select Town of Current Employer</label>
                <input type="text" id="town_of_current_employer">
            </div>
            <div class="form-group">
                <label for="contact_number">Enter Valid Contact Number</label>
                <input type="tel" id="contact_number">
            </div>
            <div class="btn-container">
                <button type="button" id="prevBtn2" class="btn btn-secondary">Previous</button>
                <button type="button" id="nextBtn3" class="btn btn-primary">Next</button>
            </div>
        </div>
        <!-- Section 4 -->
        <div id="section4" style="display: none;">
            <div class="form-group">
                <label for="email_address">Enter Valid Email Address</label>
                <input type="email" id="email_address">
            </div>
            <div class="form-group">
                <label>Select Preferred Method of Communication:</label><br>
                <input type="radio" id="email" name="communication_method" value="Email">
                <label for="email">Email</label>
                <input type="radio" id="im" name="communication_method" value="IM">
                <label for="im">Instant Messaging (IM)</label>
            </div>
            <div class="form-group">
                <label for="profile_picture">Upload Profile Picture</label>
                <input type="file" id="profile_picture">
            </div>
            <div class="btn-container">
                <button type="button" id="prevBtn3" class="btn btn-secondary">Previous</button>
                <button type="submit" id="saveBtn" class="btn btn-primary">Save Profile</button>
            </div>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $(document).ready(function() {
        // Next Button 1
        $("#nextBtn1").click(function() {
            $("#section1").slideUp();
            $("#section2").slideDown();
        });

        // Previous Button 1
        $("#prevBtn1").click(function() {
            $("#section2").slideUp();
            $("#section1").slideDown();
        });

        // Next Button 2
        $("#nextBtn2").click(function() {
            $("#section2").slideUp();
            $("#section3").slideDown();
        });

        // Previous Button 2
        $("#prevBtn2").click(function() {
            $("#section3").slideUp();
            $("#section2").slideDown();
        });

        // Next Button 3
        $("#nextBtn3").click(function() {
            $("#section3").slideUp();
            $("#section4").slideDown();
        });

        // Previous Button 3
        $("#prevBtn3").click(function() {
            $("#section4").slideUp();
            $("#section3").slideDown();
        });
    });
</script>
</body>
</html>
