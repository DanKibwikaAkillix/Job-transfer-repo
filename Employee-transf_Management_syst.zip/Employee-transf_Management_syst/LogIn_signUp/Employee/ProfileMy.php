<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Transfer Portal Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    
    

    ?>
    
    
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        .dashboard0 {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .sidebar0 {
            background-color: #44576D;
            color: #fff;
            width: 250px; /* Adjusted width */
            flex-shrink: 0;
            padding: 20px;
            transition: transform 0.3s ease-in-out;
            position: fixed;
            top: 0;
            bottom: 0;
            overflow-y: auto;
            border-radius: 0px 10px 10px 0px;
            z-index: 1000;
        }
        .sidebar0 ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar0 li {
            margin-bottom: 15px;
        }
        .sidebar0 a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            transition: background-color 0.3s, color 0.3s;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 5px;
        }
        .sidebar0 a:hover {
            background-color: #5e738c;
            color: #fff;
        }
        .sidebar0 a i {
            margin-right: 10px;
        }
        .main-content0 {
            flex-grow: 1;
            padding: 20px;
            margin-left: 250px;
        }
        .menu-icon0 {
            display: none;
            font-size: 24px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .menu-icon0.active {
            transform: rotate(90deg);
        }
        @media (max-width: 768px) {
            .dashboard0 {
                overflow-x: hidden;
            }
            .sidebar0 {
                left: -250px;
            }
            .sidebar0.active {
                left: 0;
            }
            .main-content0 {
                margin-left: 0;
                padding-top: 80px;
            }
            .menu-icon0 {
                display: block;
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 1100;
            }
        }
        .profile0 {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }
        .profile0 img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .username0 {
            font-size: 16px;
        }

        .mainLi0{
            background:#5e738c;
        }
    </style>
</head>
<body>

<?php

    session_start();


    if (isset($_GET['email'])) {
        // Retrieve the email from the GET parameters
        $email = $_GET['email'];
    
        // Assign the email to the session variable
        $_SESSION["email"] = $email;
    
        // Print or use the email as needed
        echo '<center> <h1> '.$email.' </h1> </center>';
    }
    else{
        echo '<center> <h1> Dammn it</h1> </center>';
    }
    
    ?>
   
    <div class="dashboard0">
        <div class="sidebar0" id="sidebar0">
            <div class="profile0">
                <img src="https://i.pinimg.com/564x/7f/c4/c6/7fc4c6ecc7738247aac61a60958429d4.jpg" alt="Profile Picture">
                <div class="username0">John Doe</div> <!-- Placeholder username -->
            </div>
            <ul>
                <li ><a href="myportal.php"><i class="fas fa-tasks"></i> View Applications</a></li>
                <li class="mainLi"><a href="ProfileMy.php"><i class="fas fa-user"></i> View Profile</a></li>
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
            </ul>
        </div>
        <div class="main-content0">
            <div class="menu-icon0" onclick="toggleSidebar0()"><i class="fas fa-bars"></i></div>
            <!-- Your main content goes here -->
            <div style="width:90%; margin-left:30px; ">
                <?php include ('ProfileUpdate.php'); ?>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <script>
    function toggleSidebar0() {
        var sidebar0 = document.getElementById('sidebar0');
        var menuIcon0 = document.querySelector('.menu-icon0');
        sidebar0.classList.toggle('active');
        menuIcon0.classList.toggle('active');
    }

    // Close sidebar when clicking outside of it
    window.onclick = function(event) {
        var sidebar0 = document.getElementById('sidebar0');
        var menuIcon0 = document.querySelector('.menu-icon0');
        if (!event.target.closest('.sidebar0') && !event.target.closest('.menu-icon0')) {
            sidebar0.classList.remove('active');
            menuIcon0.classList.remove('active');
        }
    };
</script>
</body>
</html>
