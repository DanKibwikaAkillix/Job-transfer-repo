<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url("https://img.freepik.com/premium-vector/abstract-white-shapes-background_79603-1360.jpg?w=826");
            background-size: cover;
            background-attachment: fixed;
        }

        .profile {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 50px 20px;
            overflow-x: hidden; /* Hide horizontal overflow */
        }

        .profile-slider {
            display: flex;
            transition: transform 0.3s ease;
        }

        .profile-section {
            max-width: 500px;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-right: 20px;
            flex: 0 0 auto; /* Ensure each section takes its own width */
        }

        .profile-picture-container {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            overflow: hidden;
            margin: 0 auto 20px;
            border: 5px solid #007bff;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            cursor: pointer;
        }

        .profile-picture-container:hover button {
            display: block;
        }

        .profile-picture {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-picture-container button {
            display: none;
            position: absolute;
            bottom: 5px;
            right: 5px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 50%;
            padding: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .field {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        label {
            font-weight: bold;
            margin-right: 10px;
            flex: 0 0 120px; /* Adjust label width */
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            flex: 1; /* Take remaining width */
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .input-icon {
            color: #aaa;
            margin-right: 5px;
        }

        .password-toggle {
            cursor: pointer;
            color: #007bff;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        input[type="file"] {
            display: none;
        }

        /* Style the date input */
        input[type="date"] {
            appearance: none;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            width: calc(100% - 2px); /* Adjust width */
            margin-top: 5px; /* Add some spacing */
        }

        /* Responsive styles */
        @media only screen and (max-width: 600px) {
            .profile {
                flex-direction: column;
                align-items: center;
            }
            .profile-section {
                margin-right: 0;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="profile">
        <div class="profile-slider">
            <div class="profile-section">
                <h2>Personal Information</h2>
                <div class="field">
                    <label for="firstname"><i class="fas fa-user input-icon"></i>First Name:</label>
                    <input type="text" id="firstname" placeholder="John">
                </div>
                <div class="field">
                    <label for="lastname"><i class="fas fa-user input-icon"></i>Last Name:</label>
                    <input type="text" id="lastname" placeholder="Doe">
                </div>
                <div class="field">
                    <label for="phonenumber"><i class="fas fa-phone input-icon"></i>Phone Number:</label>
                    <input type="text" id="phonenumber" placeholder="123-456-7890">
                </div>
                <div class="field">
                    <label for="email"><i class="fas fa-envelope input-icon"></i>Email:</label>
                    <input type="email" id="email" placeholder="john@example.com">
                </div>
                <div class="field">
                    <label for="gender"><i class="fas fa-venus-mars input-icon"></i>Gender:</label>
                    <select id="gender">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="field">
                    <label for="dob"><i class="fas fa-calendar input-icon"></i>Date of Birth:</label>
                    <input type="date" id="dob">
                </div>
                <div class="field">
                    <label for="address"><i class="fas fa-map-marker-alt input-icon"></i>Address:</label>
                    <input type="text" id="address" placeholder="123 Street, City, Country">
                </div>
            </div>
            <div class="profile-section">
                <!-- <label>Profile Picture</label> -->
                <label for="profile-picture" class="profile-picture-container">
                    <img src="https://i.pinimg.com/564x/7f/c4/c6/7fc4c6ecc7738247aac61a60958429d4.jpg" alt="Profile Picture" class="profile-picture">
                    <button>Change</button>
                </label>
                <input type="file" id="profile-picture" accept="image/*" onchange="displayProfilePicture(this)">
                <div class="field">
                    <label for="jobtitle"><i class="fas fa-briefcase input-icon"></i>Job Title:</label>
                    <input type="text" id="jobtitle" placeholder="Software Engineer">
                </div>
                <div class="field">
                    <label for="linkedin"><i class="fab fa-linkedin input-icon"></i>LinkedIn:</label>
                    <input type="text" id="linkedin" placeholder="https://www.linkedin.com/in/johndoe">
                </div>
                <div class="field">
                    <label for="othersocial"><i class="fas fa-users input-icon"></i>Other Social Media:</label>
                    <input type="text" id="othersocial" placeholder="Twitter, Facebook, etc.">
                </div>
                <div class="field">
                    <label for="password"><i class="fas fa-lock input-icon"></i>Password:</label>
                    <input type="password" id="password" placeholder="Enter your password">
                    <span class="password-toggle" onclick="togglePasswordVisibility()">Show</span>
                </div>
                <!-- Additional fields can be added here -->
                <button onclick="saveChanges()">Save Changes</button>
            </div>
        </div>
    </div>

    <!-- Navigation Slider -->
    <!-- <div class="nav-slider">
        <button class="nav-button" onclick="previousSection()">Previous</button>
        <button class="nav-button" onclick="nextSection()">Next</button>
    </div> -->

    <script>
        let currentIndex = 0;
        const profileSections = document.querySelectorAll('.profile-section');
        const profileSlider = document.querySelector('.profile-slider');

        function previousSection() {
            if (currentIndex > 0) {
                currentIndex--;
                updateSliderPosition();
            }
        }

        function nextSection() {
            if (currentIndex < profileSections.length - 1) {
                currentIndex++;
                updateSliderPosition();
            }
        }

        function updateSliderPosition() {
            const newPosition = -currentIndex * profileSections[0].offsetWidth;
            profileSlider.style.transform = `translateX(${newPosition}px)`;
        }

        function displayProfilePicture(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var img = input.parentElement.querySelector('.profile-picture');
                    img.src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        function togglePasswordVisibility() {
            var passwordField = document.getElementById('password');
            var passwordToggle = document.querySelector('.password-toggle');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordToggle.textContent = 'Hide';
            } else {
                passwordField.type = 'password';
                passwordToggle.textContent = 'Show';
            }
        }

        function saveChanges() {
            // Implement functionality to save changes to the profile
            alert('Changes saved successfully!');
        }
    </script>
</body>
</html>
