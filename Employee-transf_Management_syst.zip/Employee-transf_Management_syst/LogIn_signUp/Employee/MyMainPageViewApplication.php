<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Job Transfer Opportunities</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url("https://img.freepik.com/premium-vector/abstract-white-shapes-background_79603-1360.jpg?w=826");
            background-size: cover;
            background-attachment: fixed;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
            margin-bottom: 20px;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            min-width: 160px;
            z-index: 1;
            border-radius: 5px;
            padding: 5px 0;
        }
        .dropdown-content a {
            color: #333;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        .dropdown-content a:hover {
            background-color: #ddd;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .dropdown:hover .dropbtn {
            background-color: #ddd;
        }
        .dropbtn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        .dropbtn i {
            margin-right: 5px;
        }
        .dropbtn:hover {
            background-color: #0056b3;
        }
        .opportunity {
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 8px;
            background-color: #f9f9f9;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            transition: background-color 0.3s;
        }
        .opportunity:hover {
            background-color: #e9e9e9;
        }
        .opportunity-details {
            margin-left: 20px;
        }
        .apply-button {
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .apply-button:hover {
            background-color: #218838;
        }
        .pagination {
            justify-content: center;
        }
        .image-box {
            width: 150px;
            height: 150px;
            overflow: hidden;
            border-radius: 8px;
        }
        .image-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>View Job Transfer Opportunities</h1>
    <div class="dropdown">
        <button class="dropbtn"><i class="fas fa-list"></i> Filter Opportunities</button>
        <div class="dropdown-content">
            <a href="#" id="viewAll">All Opportunities</a>
            <a href="#" id="viewOpen">Open Opportunities</a>
            <a href="#" id="viewClosed">Closed Opportunities</a>
        </div>
    </div>
    <div id="opportunitiesList">
        <!-- Opportunity list will be dynamically populated here -->
    </div>
    <!-- Pagination -->
    <nav aria-label="Opportunity Pagination">
        <ul class="pagination" id="paginationList">
            <!-- Pagination items will be dynamically populated here -->
        </ul>
    </nav>

</div>

<script>
    // Sample data for job transfer opportunities (you can replace this with actual data)
    var opportunities = [
        { id: 1, title: "Opportunity 1", status: "Open", position: "Software Engineer", region: "North America" },
        { id: 2, title: "Opportunity 2", status: "Closed", position: "Data Analyst", region: "Europe" },
        { id: 3, title: "Opportunity 3", status: "Open", position: "Project Manager", region: "Asia" },
        { id: 4, title: "Opportunity 4", status: "Closed", position: "Sales Representative", region: "South America" },
        { id: 5, title: "Opportunity 5", status: "Open", position: "Marketing Specialist", region: "Africa" },
        // Adding more sample records to make it 50
        { id: 6, title: "Opportunity 6", status: "Open", position: "Software Developer", region: "North America" },
        { id: 7, title: "Opportunity 7", status: "Closed", position: "Data Scientist", region: "Europe" },
        { id: 8, title: "Opportunity 8", status: "Open", position: "Project Lead", region: "Asia" },
        { id: 9, title: "Opportunity 9", status: "Closed", position: "Marketing Manager", region: "South America" },
        { id: 10, title: "Opportunity 10", status: "Open", position: "Product Manager", region: "Africa" },
        { id: 11, title: "Opportunity 11", status: "Open", position: "Software Engineer", region: "North America" },
        { id: 12, title: "Opportunity 12", status: "Closed", position: "Data Analyst", region: "Europe" },

    ];

    var itemsPerPage = 10; // Change this value to adjust items per page

    // Function to populate the opportunities list
    function populateOpportunitiesList(page) {
        var opportunitiesList = document.getElementById('opportunitiesList');
        opportunitiesList.innerHTML = '';
        var startIndex = (page - 1) * itemsPerPage;
        var endIndex = startIndex + itemsPerPage;
        var paginatedOpportunities = opportunities.slice(startIndex, endIndex);
        paginatedOpportunities.forEach(function(opportunity) {
            var opportunityItem = document.createElement('div');
            opportunityItem.classList.add('opportunity');

            // Create the image box
            var imageBox = document.createElement('div');
            imageBox.classList.add('image-box');
            var image = document.createElement('img');
            image.src = 'https://i.pinimg.com/236x/15/50/aa/1550aafe30f1541086589044703d8773.jpg'; // Image source
            imageBox.appendChild(image);

            // Create the opportunity details container
            var detailsContainer = document.createElement('div');
            detailsContainer.classList.add('opportunity-details');

            // Populate opportunity details
            detailsContainer.innerHTML = `
                <div class="title">${opportunity.title}</div>
                <div class="position"><strong>Position:</strong> ${opportunity.position}</div>
                <div class="region"><strong>Region:</strong> ${opportunity.region}</div>
            `;

            // Append image box and details container to opportunity item
            opportunityItem.appendChild(imageBox);
            opportunityItem.appendChild(detailsContainer);

            if (opportunity.status === 'Open') {
                var applyButton = document.createElement('a'); // Change button to anchor element
                applyButton.classList.add('apply-button');
                applyButton.innerText = 'Apply';
                applyButton.href = 'CreateNewApp.php'; // Set the href attribute to the desired page
                opportunityItem.appendChild(applyButton);
            }
            opportunitiesList.appendChild(opportunityItem);
        });
    }

    // Function to populate pagination
    function populatePagination() {
        var totalPages = Math.ceil(opportunities.length / itemsPerPage);
        var paginationList = document.getElementById('paginationList');
        paginationList.innerHTML = '';
        for (var i = 1; i <= totalPages; i++) {
            var pageItem = document.createElement('li');
            pageItem.classList.add('page-item');
            var pageLink = document.createElement('a');
            pageLink.classList.add('page-link');
            pageLink.href = '#';
            pageLink.innerText = i;
            pageLink.addEventListener('click', function(event) {
                event.preventDefault();
                var pageNumber = parseInt(event.target.innerText);
                populateOpportunitiesList(pageNumber);
            });
            pageItem.appendChild(pageLink);
            paginationList.appendChild(pageItem);
        }
    }

    // Event listeners for view links
    document.getElementById('viewAll').addEventListener('click', function() {
        populateOpportunitiesList(1);
        populatePagination();
    });

    document.getElementById('viewOpen').addEventListener('click', function() {
        populateOpportunitiesList(1);
        populatePagination();
    });

    document.getElementById('viewClosed').addEventListener('click', function() {
        populateOpportunitiesList(1);
        populatePagination();
    });

    // Initial population of opportunities list and pagination
    populateOpportunitiesList(1);
    populatePagination();
</script>
</body>
</html>
